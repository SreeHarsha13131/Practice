package JavaConcepts;

public class InstanceOf {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        
        // Access command-line arguments
        for (String arg : args) {
            System.out.println("Argument: " + arg);
        }
    }
	
}