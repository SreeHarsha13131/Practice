package Prorams;

public class Ternaryoperatorpgm2 {
	public static void main(String[] args) {
		int x=10;
		int y=40;
		int z=30;
		int largest = (x>y)?(x>z?x:z):(y>z?y:z);
		System.out.println(largest);
		
	int a=100;
	int b=200;
	int c=300;
	int largest1=(a>b)?(a>c?a:c):(b>c?b:c);
	System.out.println(largest1);
	
	}

}
