package Prorams;

public class TernaryOperatorpgm1 {
	public static void main(String[] args) {
		int x=10;
		int y=30;
		int largest = (x>y)?x:y;
		System.out.println(largest);
	}
}
