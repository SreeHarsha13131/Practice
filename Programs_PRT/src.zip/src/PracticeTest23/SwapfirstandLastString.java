package PracticeTest23;

public class SwapfirstandLastString {
	public static void main(String[] args) {
		String[] s = {"Hello","World","Bharath"};
		String temp = s[0];
		s[0] = s[s.length-1];
		s[s.length-1] = temp;
		for(int i = 0 ; i<s.length;i++) {
			System.out.print(s[i]+",");
		}
	}
}
