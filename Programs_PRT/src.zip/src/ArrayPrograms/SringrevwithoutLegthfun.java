package ArrayPrograms;

public class SringrevwithoutLegthfun {
	public static void main(String[] args) {
		String s="mango";
		String s2="";
		String rev="";
		int length=s.compareTo(s2);
		for(int i=length-1;i>=0;i--)
		{
			rev=rev+s.charAt(i);
		}
		System.out.println(rev);
	}
}
